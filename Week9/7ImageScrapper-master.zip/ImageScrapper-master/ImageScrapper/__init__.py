# -*- coding: utf-8 -*-
from dao.DAO import DAO
from imagescrapperservice import ImageScrapperService