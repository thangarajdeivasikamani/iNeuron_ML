# ineuron_megatron

##Install requirements.txt

##Model can be downloaded from:-https://drive.google.com/drive/folders/1neHfilNkrCwtry3dA7bTCADH3EheKdYo?usp=sharing

